"""Script auxiliar del proyecto: ingeniería de características para el modelo de deserción.
Lo usan el notebook (entrenamiento) y la app de Streamlit (predicción)."""
import numpy as np
import pandas as pd


def _tasa(aprobadas, inscritas):
    """Aprobadas / inscritas; 0 cuando no inscribió asignaturas."""
    return np.where(inscritas > 0, aprobadas / inscritas.replace(0, 1), 0.0)


def agregar_caracteristicas(X: pd.DataFrame) -> pd.DataFrame:
    X = X.copy()
    X["tasa_aprob_1er_sem"] = _tasa(X["curricular_units_1st_sem_approved"],
                                    X["curricular_units_1st_sem_enrolled"])
    if "curricular_units_2nd_sem_approved" in X:
        X["tasa_aprob_2do_sem"] = _tasa(X["curricular_units_2nd_sem_approved"],
                                        X["curricular_units_2nd_sem_enrolled"])
        X["cambio_aprobadas"] = (X["curricular_units_2nd_sem_approved"]
                                 - X["curricular_units_1st_sem_approved"])
        X["cambio_promedio"] = (X["curricular_units_2nd_sem_grade"]
                                - X["curricular_units_1st_sem_grade"])
    return X
